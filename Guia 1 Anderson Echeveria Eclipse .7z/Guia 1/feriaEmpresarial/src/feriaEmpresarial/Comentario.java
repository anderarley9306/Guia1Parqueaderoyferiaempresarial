package feriaEmpresarial;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Comentario {
    private Visitante visitante;
    private Empresa empresa;
    private String texto;
    private LocalDateTime fecha;
    private int calificacion;

    public Comentario(Visitante visitante, Empresa empresa, String texto, int calificacion,LocalDate fecha) {
        this.visitante = visitante;
        this.empresa = empresa;
        this.texto = texto;
        this.calificacion = calificacion;
        this.fecha = LocalDateTime.now();
    }
    
    public LocalDateTime getfecha() {
		// TODO - implement Vehiculo.getHoraIngreso
		return fecha;
	}

	/**
	 * 
	 * @param localDateTime
	 */
	public void setfecha(LocalDateTime localDateTime) {
		// TODO - implement Vehiculo.setHoraIngreso
		this.fecha = localDateTime;
	}
    
   
    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }

    @Override
    public String toString() {
        return "[" + fecha + "] " + visitante.getNombre() + " → " + empresa.getNombre() + 
               " | Calificación: " + calificacion + "/5 | " + texto;
    }
}