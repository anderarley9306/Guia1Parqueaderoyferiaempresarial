package feriaEmpresarial;

public class Visitante {
    private String nombre;
    private String identificacion;
    private String correo;

    public Visitante(String nombre, String identificacion) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.correo = "";
    }

    public String getNombre() { 
    	return nombre; 
    	}
    public void setNombre(String nombre) {
    	this.nombre = nombre; 
    	}

    public String getIdentificacion() { 
    	return identificacion; 
    	}
    public void setIdentificacion(String identificacion) {
    	this.identificacion = identificacion;
    	}
    public String getcorreo() { 
    	return correo; 
    	}
    public void setcorreo(String correo) { 
    	this.correo = correo; 
    	}
    @Override
    public String toString() {
        return "Visitante: " + nombre + " | ID: " + identificacion + "Correo" + correo; 
    }
}