package feriaEmpresarial;

public class Stand {
	private int numero;
    private String ubicacion;
    private double tamaño;
    private Empresa empresa;
    
    private static int contador = 1;

    public Stand(String ubicacion, double tamaño, Empresa empresa) {
        this.numero = contador++;
        this.ubicacion = ubicacion;
        this.tamaño = tamaño;
        this.empresa = empresa;
    }
    public Stand(String ubicacion, Empresa empresa) {
        this.ubicacion = ubicacion;
        this.empresa = empresa;
    
    }
    public int getNumero() { 
    	return numero; 
    	}
    public void setNumero(int numero) { 
    	this.numero = numero; 
    	
    }
    public double getTamaño() {
    	return tamaño; 
    }
    

    public String getUbicacion() { 
    	return ubicacion; 
    	}
    public void setUbicacion(String ubicacion) { 
    	this.ubicacion = ubicacion; 
    	}

    public Empresa getEmpresa() { 
    	return empresa; 
    	}
    public void setEmpresa(Empresa empresa) {
    	this.empresa = empresa; 
    	}

    @Override
    public String toString() {
        return "Stand en: " + ubicacion + " | Empresa: " + empresa.getNombre();
    }
}