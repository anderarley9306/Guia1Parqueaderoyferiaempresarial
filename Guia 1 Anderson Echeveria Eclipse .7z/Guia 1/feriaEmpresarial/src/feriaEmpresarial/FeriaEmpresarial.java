package feriaEmpresarial;

import java.util.ArrayList;

import java.util.Scanner;

public class FeriaEmpresarial {
	
	// definimos las listas para almacenar la información que ingrese el usuario
	
    private ArrayList<Empresa> empresas = new ArrayList<>();
    private ArrayList<Stand> stands = new ArrayList<>();
    private ArrayList<Visitante> visitantes = new ArrayList<>();
    private ArrayList<Comentario> comentarios = new ArrayList<>();

    
    // Creamos un objeto para llamar el mmenu inicial
    
    public static void main(String[] args) {
        FeriaEmpresarial feria = new FeriaEmpresarial();
        feria.menu();
    }

    
    // Creamos el menu, con las respectivas opciones que tiene el usuario para seleccionar, asi mismo mantenemos activo el menu hasta que sea 0
    public void menu() {
        Scanner sc = new Scanner(System.in);
        String o;

        do {
            System.out.println("\n ==BIENVENIDO A NUESTRA FERIA EMPRESARIAL== ");
            System.out.println("1. Registrar empresa");
            System.out.println("2. Registrar stand");
            System.out.println("3. Registrar visitante");
            System.out.println("4. Dejar comentario");
            System.out.println("5. Reportes");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            o = sc.nextLine().trim();
            switch (o) {
                case "1" -> registrarEmpresa(sc);
                case "2" -> registrarStand(sc);
                case "3" -> registrarVisitante(sc);
                case "4" -> dejarComentario(sc);
                case "5" -> menuReportes();
                case "0" -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida");
            }
        } while (!o.equals("0"));
    }

    //  Creamos un menu de reportes, asi mismo imprimimos las listas de acuerdo a la opcion que elija, en caso de ser 0 regresa al anterior menu
    public void menuReportes() {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("\n--- Reportes ---");
            System.out.println("1. Empresas");
            System.out.println("2. Stands");
            System.out.println("3. Visitantes");
            System.out.println("4. Comentarios");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            opcion = sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                case 1 -> empresas.forEach(System.out::println);
                case 2 -> stands.forEach(System.out::println);
                case 3 -> visitantes.forEach(System.out::println);
                case 4 -> comentarios.forEach(System.out::println);
                case 0 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    // Creamos la captura de datos para Registrar empresa
    private void registrarEmpresa(Scanner sc) {
        System.out.print("Nombre empresa: ");
        String nombre = sc.nextLine();
        System.out.print("Sector: ");
        String sector = sc.nextLine();
        System.out.print("Correo electrónico: ");
        String correo = sc.nextLine();
        empresas.add(new Empresa(nombre, sector, correo));
        System.out.println(" Empresa registrada.");
    }

    // se valida inicialmente, si hay empresas registradas para asignar un stand, si hay solicita datos y los almacena en la lista
    private void registrarStand(Scanner sc) {
        if (empresas.isEmpty()) {
            System.out.println(" No hay empresas registradas.");
            return;
        }
        System.out.println("Seleccione empresa para el stand:");
        for (int i = 0; i < empresas.size(); i++) {
            System.out.println((i + 1) + ". " + empresas.get(i).getNombre());
        }
        int idx = sc.nextInt() - 1;
        sc.nextLine();
        System.out.print("Ubicación stand: ");
        String ubicacion = sc.nextLine();
        System.out.print("Tamaño (m²): ");
        double tamaño = sc.nextDouble();
        sc.nextLine();
        stands.add(new Stand(ubicacion, tamaño, empresas.get(idx)));
        System.out.println("Stand registrado.");
    }
    
    // se solicitan datos para registrar un nuevo visitante 
    private void registrarVisitante(Scanner sc) {
        System.out.print("Nombre visitante: ");
        String nombre = sc.nextLine();
        System.out.print("Identificación: ");
        String id = sc.nextLine();
        System.out.print("Correo electrónico: ");
        String correo = sc.nextLine();
        visitantes.add(new Visitante(nombre, correo));
        System.out.println("Visitante registrado.");
    }
    
    
    // se valida el visitante para dejar el comentario, si esta vacio pide crear un visitante, si no se pide la informacion para dejar el comentario

    private void dejarComentario(Scanner sc) {
        if (visitantes.isEmpty() || empresas.isEmpty()) {
            System.out.println("Debe haber al menos un visitante y una empresa registrados.");
            return;
        }
        System.out.println("Seleccione visitante:");
        for (int i = 0; i < visitantes.size(); i++) {
            System.out.println((i + 1) + ". " + visitantes.get(i).getNombre());
        }
        int idxVisitante = sc.nextInt() - 1;

        System.out.println("Seleccione empresa:");
        for (int i = 0; i < empresas.size(); i++) {
            System.out.println((i + 1) + ". " + empresas.get(i).getNombre());
        }
        int idxEmpresa = sc.nextInt() - 1;
        sc.nextLine();

        System.out.print("Comentario: ");
        String texto = sc.nextLine();

        System.out.print("Calificación (1-5): ");
        int calificacion = sc.nextInt();
        sc.nextLine();

        comentarios.add(new Comentario(
            visitantes.get(idxVisitante),
            empresas.get(idxEmpresa),
            texto,
            calificacion, null
        ));
        System.out.println("Comentario registrado.");
    }
}
