import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Parqueadero {
	
	private List<Vehiculo> Vehiculos;
	private int valorminuto;
	private String nombre;
	public String telefono;
	
	 public Parqueadero(String nombre, String telefono, int valorminuto) {
	        this.nombre = nombre;
	        this.telefono = telefono;
	        this.valorminuto = valorminuto;
	        this.Vehiculos = new ArrayList<>();
	    }
	

	public void entrada(Vehiculo Vehiculo) {
        Vehiculo.setHoraIngreso(LocalDateTime.now());
        Vehiculos.add(Vehiculo);
        System.out.println("Vehículo " + Vehiculo.getPlaca() + " ingresó.");
    }
	

	 public double salida(String Placa) {
	        Vehiculo v = buscarVehiculo(Placa);
	        if (v == null) {
	            System.out.println("No se encontró vehículo con Placa " + Placa);
	            return 0;
	        }

	        long minutos = Duration.between(v.getHoraIngreso(), LocalDateTime.now()).toMinutes();
	        if (minutos == 0) minutos = 1; // mínimo 1 minuto

	        double costo = calcularCosto(v, minutos);

	        Vehiculos.remove(v);
	        System.out.println("Vehículo " + Placa + " salió. Tiempo: " + minutos + " min. Costo: $" + costo);
	        return costo;
	    }

	    // Calcular costo según tipo de vehículo
	    private double calcularCosto(Vehiculo v, long minutos) {
	        if (v instanceof Automovil) {
	            return minutos * valorminuto;
	        } else if (v instanceof Motocicleta) {
	            return minutos * (valorminuto * 0.5); // ejemplo: 50% menos
	        } else if (v instanceof Camion) {
	            return minutos * (valorminuto * 2); // ejemplo: doble tarifa
	        }
	        return minutos * valorminuto;
	    }

	    // Buscar vehículo por Placa
	    private Vehiculo buscarVehiculo(String Placa) {
	        for (Vehiculo v : Vehiculos) {
	            if (v.getPlaca().equalsIgnoreCase(Placa)) {
	                return v;
	            }
	        }
	        return null;
	    }

	    // Mostrar vehículos actuales
	    public void mostrarVehiculos() {
	        if (Vehiculos.isEmpty()) {
	            System.out.println("No hay vehículos en el parqueadero.");
	        } else {
	            System.out.println("Vehículos presentes:");
	            for (Vehiculo v : Vehiculos) {
	                System.out.println("- " + v.getPlaca() + " (" + v.getMarca() + ")");
	            }
	        }
	    }

	    // Getters y Setters
	    public int getValorminuto() {
	        return valorminuto;
	    }

	    public void setValorminuto(int valorminuto) {
	        this.valorminuto = valorminuto;
	    }

	    public String getNombre() {
	        return nombre;
	    }

	    public void setNombre(String nombre) {
	        this.nombre = nombre;
	    }

	    public String getTelefono() {
	        return telefono;
	    }

	    public void setTelefono(String telefono) {
	        this.telefono = telefono;
	    }
	}