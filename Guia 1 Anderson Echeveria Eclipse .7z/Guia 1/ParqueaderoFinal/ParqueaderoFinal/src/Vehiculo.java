import java.time.LocalDateTime;

public class Vehiculo {

	private String Placa;
	private String Marca;
	private String Modelo;
	private LocalDateTime HoraIngreso;
	private String Color;
	
	  public Vehiculo(String Placa, String Marca, String Modelo, String Color) {
	        this.Placa = Placa;
	        this.Marca = Marca;
	        this.Modelo = Modelo;
	        this.Color = Color;
	        this.HoraIngreso = LocalDateTime.now(); // Se asigna al entrar
	    }
	
	

	public String getPlaca() {
		// TODO - implement Vehiculo.getPlaca
	
		return Placa;
	}

	/**
	 * 
	 * @param Placa
	 */
	public void setPlaca(String Placa) {
		// TODO - implement Vehiculo.setPlaca
		
		this.Placa = Placa;
	}

	public String getMarca() {
		// TODO - implement Vehiculo.getMarca
		return Marca;
	}

	/**
	 * 
	 * @param Marca
	 */
	public void setMarca(String Marca) {
		// TODO - implement Vehiculo.setMarca
		this.Marca = Marca;
	}

	public String getModelo() {
		// TODO - implement Vehiculo.getModelo
		return Modelo;
	}

	/**
	 * 
	 * @param Modelo
	 */
	public void setModelo(String Modelo) {
		// TODO - implement Vehiculo.setModelo
		this.Modelo = Modelo;
	}

	public LocalDateTime getHoraIngreso() {
		// TODO - implement Vehiculo.getHoraIngreso
		return HoraIngreso;
	}

	/**
	 * 
	 * @param localDateTime
	 */
	public void setHoraIngreso(LocalDateTime localDateTime) {
		// TODO - implement Vehiculo.setHoraIngreso
		this.HoraIngreso = localDateTime;
	}

	public String getColor() {
		// TODO - implement Vehiculo.getColor
		return Color;
	}

	/**
	 * 
	 * @param Color
	 */
	public void setColor(String Color) {
		// TODO - implement Vehiculo.setColor
		this.Color = Color;
	}

}