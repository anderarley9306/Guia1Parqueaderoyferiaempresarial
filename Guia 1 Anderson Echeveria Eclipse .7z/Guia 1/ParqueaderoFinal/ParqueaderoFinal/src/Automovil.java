public class Automovil extends Vehiculo {

	private String TipoCombustible;
	private boolean esHibrido;
	
	  public Automovil(String Placa, String Marca, String Modelo, String Color, String TipoCombustible,boolean esHibrido ) {
	        super(Placa, Marca, Modelo, Color);
	        this.TipoCombustible = TipoCombustible;
	        this.esHibrido = esHibrido;
	        
	  }


	    public String getTipoCombustible() {
	        return TipoCombustible;
	    }

	    public void setTipoCombustible(String TipoCombustible) {
	        this.TipoCombustible = TipoCombustible;
	    }
	

	public boolean getEsHibrido() {
		return this.esHibrido;
	}

	/**
	 * 
	 * @param esHibrido
	 */
	public void setEsHibrido(boolean esHibrido) {
		this.esHibrido = esHibrido;
	}

}