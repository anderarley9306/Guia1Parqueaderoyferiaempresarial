import java.util.Scanner;

// se crea la clase principal main quien iniciara con el menu inicial

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // damos datos relevantes del parqueadero,como nombre, telefono y un valor por minuto
        Parqueadero parqueadero = new Parqueadero("Parqueadero de Anderson", "1233547", 100); // $100 por minuto

        // Imprime el menu inicial y nos lleva a la diferente captura de datos o liquidacion segun la opcion que elije
        int opcion;
        do {
            System.out.println("\n--- MENÚ PARQUEADERO ---");
            System.out.println("1. Ingresar vehículo");
            System.out.println("2. Registrar salida");
            System.out.println("3. Consultar vehículos presentes");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.println("Tipo de vehículo (1. Automóvil, 2. Motocicleta, 3. Camión): ");
                    int tipo = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Placa: ");
                    String Placa = sc.nextLine();
                    System.out.print("Marca: ");
                    String Marca = sc.nextLine();
                    System.out.print("Modelo: ");
                    String Modelo = sc.nextLine();
                    System.out.print("Color: ");
                    String Color = sc.nextLine();

                    switch (tipo) {
                        case 1 -> {
                            System.out.print("Tipo de Combustible: ");
                            String TipoCombustible = sc.nextLine();
                            parqueadero.entrada(new Automovil(Placa, Marca, Modelo, Color, TipoCombustible, false));
                        }
                        case 2 -> {
                            System.out.print("Cilindraje: ");
                            int cilindraje = sc.nextInt();
                            sc.nextLine();
                            parqueadero.entrada(new Motocicleta(Placa, Marca, Modelo, Color, cilindraje));
                        }
                        case 3 -> {
                            System.out.print("Capacidad de Carga (toneladas): ");
                            double Carga = sc.nextDouble();
                            sc.nextLine();
                            parqueadero.entrada(new Camion(Placa, Marca, Modelo, Color, Carga));
                        }
                        default -> System.out.println("Tipo de vehículo inválido.");
                    }
                }
                case 2 -> {
                    System.out.print("Ingrese Placa del vehículo: ");
                    String Placa = sc.nextLine();
                    parqueadero.salida(Placa);
                }
                case 3 -> parqueadero.mostrarVehiculos();
                case 0 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}