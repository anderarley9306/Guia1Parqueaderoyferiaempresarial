public class Camion extends Vehiculo {
    private double CapacidadCarga;

    public Camion(String Placa, String Marca, String Modelo, String Color, double CapacidadCarga) {
        super(Placa, Marca, Modelo, Color);
        this.CapacidadCarga = CapacidadCarga;
    }

    public double getCapacidadCarga() {
        return CapacidadCarga;
    }

    public void setCapacidadCarga(double CapacidadCarga) {
        this.CapacidadCarga = CapacidadCarga;
    }
}