public class Motocicleta extends Vehiculo {
    private int Cilindraje;

    public Motocicleta(String Placa, String Marca, String Modelo, String Color, int cilindraje) {
        super(Placa, Marca, Modelo, Color);
        this.Cilindraje = cilindraje;
    }

    public int getCilindraje() {
        return Cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.Cilindraje = cilindraje;
    }
}